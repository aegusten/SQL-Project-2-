--2 i.List the book(s) which has the highest rating. 
--Show book id, book name, and the rating.

SELECT bk.BookID, bk.BookTitle, odr.Rating
FROM Book bk INNER JOIN Cart crt
ON bk.BookID = crt.BookID INNER JOIN Order_ odr
ON odr.CartID = crt.CartID
WHERE odr.Rating = 5
ORDER BY bk.BookID;

--2 ii. Find the total number of feedbacks per member. ()
--Show member id, member name, and total number of feedbacks per member

SELECT odr.MemberID, mbr.MemberFirstName + ' ' + mbr.MemberLastName AS 'Member Name', odr.Review
FROM Member mbr INNER JOIN Order_ odr
ON mbr.MemberID = odr.MemberID
WHERE odr.Review IS NOT NULL
ORDER BY mbr.MemberID;

--2.iii Find the total number of books published by each publisher. 
--Show publisher id, publisher name, and number of books published.

SELECT Publisher.PublisherID,Publisher.FirstName+' '+Publisher.LastName as 'Publisher Name',count(book.PublisherID) as'Number of Book Published' from Publisher
right join book
ON Publisher.PublisherID=Book.PublisherID
GROUP BY Publisher.PublisherID, Publisher.FirstName,Publisher.LastName
ORDER BY [Number of Book Published] DESC;

--2.iv Find the total number of books ordered by store manager from each publisher.

SELECT Publisher.PublisherID,Publisher.FirstName+' '+Publisher.LastName as 'Publisher Name',sum(book.BookStock) as'Total number of books' from Publisher
right join book
ON Publisher.PublisherID=Book.PublisherID
GROUP BY Publisher.PublisherID, Publisher.FirstName,Publisher.LastName
ORDER BY [Total number of books] DESC;

--2.V From the book table, list the books where quantity is more than the average quantity of all books. 
SELECT booktitle AS Book_Name,BookStock 
FROM book 
WHERE bookstock > (SELECT avg(bookstock) FROM book);

--2.VI Find the bestselling book(s).
select Book.BookID, Book.BookTitle, sum(Cart.Quantity) as 'Best Selling Book' from Book 
right join  Cart
on Book.BookID=Cart.BookID
right join Order_
on cart.CartID = Order_.CartID
group by Book.BookID,Book.BookTitle
order by [Best Selling Book] desc;




--2.VII Show the member(s) who spent most on buying books
select Member.MemberFirstName+' '+Member.MemberLastName as 'Member Name',sum(cart.TotalAmount) as 'Total Amount' from Member
left join Order_
on Member.MemberID=Order_.MemberID
right join Cart
on Order_.CartID=Cart.CartID
group by member.MemberFirstName,member.MemberLastName
order by [Total Amount] desc;


--2.VIII  Show the member(s) who had not make any order
select Member.MemberFirstName+' '+Member.MemberLastName as 'Member Name', Member.MemberID
from Member
where Member.MemberID not in(
select Order_.MemberID from Order_);

--2. IX A list of purchased books that have not been delivered to members. 
--The list shouldNshow member identification number, address, contact number, book serial number, book title, quantity, date and status of delivery.

select Member.MemberID,Member.MemberFirstName+' '+Member.MemberLastName as 'Member Name',
Member.MemberAddess,Book.BookID,Book.BookTitle,Order_.TotalAmount,Order_.Date_ ,order_.DeliveryStatus  from Member
right join Order_
on Member.MemberID=Order_.MemberID
right join OrderedBook
on Order_.CartID = OrderedBook.CartID
right join Book
on OrderedBook.BookID=Book.BookID
where not order_.deliverystatus  = 'Delivered';

--2. X Show the members who made more than 2 orders.
select member.MemberID,Member.MemberFirstName+' '+Member.MemberLastName as 'Member Name',sum(Cart.Quantity) as 'Total Order' ,Member.MemberPhone,Member.MemberAddess from Member
right join Cart
on Member.MemberID=Cart.MemberID
group by Member.MemberID,member.MemberFirstName,member.MemberLastName,Member.MemberPhone,Member.MemberAddess 
having sum(Cart.Quantity)>2