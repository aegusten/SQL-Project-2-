CREATE DATABASE IDB;
USE IDB;

CREATE TABLE User_table
(
    Username VARCHAR(20) PRIMARY KEY,
    Department_ID VARCHAR(10),
    Position_ID VARCHAR(10),
    Member_name CHAR(50) NOT NULL,
    Member_age INT,
    Member_gender CHAR(1),
    Member_email VARCHAR(40),
    Member_contact DEC(10, 0),
    Member_address TEXT,
    Active_status VARCHAR(10) NOT NULL
);

CREATE TABLE Department
(
    Department_ID VARCHAR(10) PRIMARY KEY,
    Department_name VARCHAR(50) NOT NULL,
);

CREATE TABLE User_Position
(
    Position_ID VARCHAR(10) PRIMARY KEY,
    Username VARCHAR(20),
    Position_name VARCHAR(15),
    Loan_number_allowed INT,
    FOREIGN KEY(Username) REFERENCES User_table(Username)
);

ALTER TABLE User_table
ADD FOREIGN KEY(Department_ID) REFERENCES Department(Department_ID);

ALTER TABLE User_table
ADD FOREIGN KEY(Position_ID) REFERENCES User_Position(Position_ID);

CREATE TABLE Login
(
	Username VARCHAR(20) FOREIGN KEY REFERENCES User_table(Username),
	Login_Password VARCHAR(30) NOT NULL
);

CREATE TABLE Fine
(
	Fine_ID VARCHAR(10) PRIMARY KEY,
	Username VARCHAR(20) FOREIGN KEY REFERENCES User_table(Username) NOT NULL,
	Borrow_ID VARCHAR(10) NOT NULL,
	Days_Overdue INT NOT NULL,
	Fine_To_Be_Paid INT NOT NULL
);

CREATE TABLE Borrowing_Activities
(
	Borrow_ID VARCHAR(10) PRIMARY KEY,
	Username VARCHAR(20) FOREIGN KEY REFERENCES User_table(Username) NOT NULL,
	Book_ID VARCHAR(10) NOT NULL,
	Borrow_Date DATE NOT NULL,
	Return_Date DATE NOT NULL,
	Due_Date DATE NOT NULL
);

ALTER TABLE Fine
ADD FOREIGN KEY(Borrow_ID) REFERENCES Borrowing_Activities(Borrow_ID);

CREATE TABLE Book
(
	Book_ID VARCHAR(10) PRIMARY KEY,
	Catalogue_ID VARCHAR(10),
	Author_ID VARCHAR(10),
	Publisher_ID VARCHAR(10),
	ISBN DEC(13,0) NOT NULL,
	Book_Title CHAR(50),
	Book_Lable CHAR(10),
	Book_Language CHAR(10),
	Published_year INT
);

ALTER TABLE Borrowing_activities
ADD FOREIGN KEY(Book_ID) REFERENCES Book(Book_ID);

CREATE TABLE Catalogue
(
	Catalogue_ID VARCHAR(10) PRIMARY KEY,
	Book_Description TEXT,
	Subject_Area VARCHAR(10)
);

CREATE TABLE Author
(
	Author_ID VARCHAR(10) PRIMARY KEY,
	Author_Name CHAR(50),
	Author_Age INT,
	Author_Email VARCHAR(40)
);

CREATE TABLE Publisher
(
	Publisher_ID VARCHAR(10) PRIMARY KEY,
	Publisher_Name CHAR(50),
	Publisher_Email VARCHAR(40),
	Publisher_Address TEXT,
	Publisher_Contact DEC(10, 0)
);

ALTER TABLE Book
ADD FOREIGN KEY(Catalogue_ID) REFERENCES Catalogue(Catalogue_ID);

ALTER TABLE Book
ADD FOREIGN KEY(Author_ID) REFERENCES Author(Author_ID);

ALTER TABLE Book
ADD FOREIGN KEY(Publisher_ID) REFERENCES Publisher(Publisher_ID);

CREATE TABLE Reservations
(
	Reserve_ID VARCHAR(10) PRIMARY KEY,
	Book_ID VARCHAR(10) FOREIGN KEY REFERENCES Book(Book_ID),
	Username VARCHAR(20) FOREIGN KEY REFERENCES User_table(Username),
	Reservation_Date DATE,
	Book_status CHAR(15)
);

INSERT INTO Department VALUES
('Dept_001', 'Faculty of Computing'),
('Dept_002', 'Faculty of Mathematics'),
('Dept_003', 'Faculty of Engineering'),
('Dept_004', 'Faculty of Psychology'),
('Dept_005', 'Faculty of Finance');

INSERT INTO User_Position VALUES
('Lbr_00001', NULL, 'Librarian', 10),
('Lec_00001', NULL, 'Lecturer', 10),
('Lec_00002', NULL, 'Lecturer', 10),
('Lec_00003', NULL, 'Lecturer', 10),
('Nms_00001', NULL, 'Normal Staff', 10),
('Std_00001', NULL, 'Student', 5),
('Std_00002', NULL, 'Student', 5),
('Std_00003', NULL, 'Student', 5),
('Std_00004', NULL, 'Student', 5),
('Std_00005', NULL, 'Student', 5),
('Std_00006', NULL, 'Student', 5);

INSERT INTO User_table VALUES
('Whiscoget67', 'Dept_004', 'Lbr_00001', 'Sebastian Higgins', 18, 'F', 'SebastianHiggins@gmail.com', 7407169086, '2239 Viking DriveWorthington, OH 43085', 'Active'),
('Bobre1950', 'Dept_001', 'Lec_00001', 'Jessica Allan', 18, 'M', 'JessicaAllan@armyspy.com', 5188992418, '2420 Valley Street Pennsville, NJ 08070', 'Active'),
('Wourell', 'Dept_003', 'Lec_00002', 'Isobel Garner', 22, 'F', 'IsobelGarner@dayrep.com', 8176164412, '944 Sardis StaDallas, TX 75207', 'Active'),
('Pragnot245', 'Dept_002', 'Lec_00003', 'Spencer Whitehead', 20, 'F', 'SpencerWhitehead@gmail.com', 8502260371,	'1588 Virgil StreetFort Walton Beach, FL 32548', 'Active'),
('Fuldebou', 'Dept_002', 'Nms_00001', 'Jamie Clayton', 19, 'M', 'JamieClayton@rhyta.com',	8609335893, '4673 Airplane Avenue Wallingford, CT 06492', 'Active'),
('Ineved123', 'Dept_002', 'Std_00001', 'Samuel Cooper', 19, 'M', 'SamuelCooper@jourrapide.com', 9897368088, '2658 Ripple Street Lincoln, MI 48742', 'Inactive'),
('Undis1954', 'Dept_001', 'Std_00002', 'Evan Freeman', 19, 'M', 'EvanFreeman@jourrapide.com', 4172310555, '4505 Lighthouse Drive Springfield, MO 65865', 'Active'),
('Haihey111', 'Dept_005', 'Std_00006', 'Farenheit Dan', 20, 'M', 'Dan@gmail.com', 1236785647, '1243 Dan Don Field, Family sites, Ohio,33489', 'Inactive'),
('Saides', 'Dept_003', 'Std_00003', 'Tia Jordan', 20, 'M', 'TiaJordan@armyspy.com', 5174806233, '2126 Elk Avenue Lansing, MI 48933', 'Active'),
('Anall1937', 'Dept_004', 'Std_00004', 'Kian Finch', 24, 'F', 'KianFinch@rhyta.com', 4193120427, '4393 Olive Street Toledo, OH 43609', 'Active'),
('Nerisfamands', 'Dept_005', 'Std_00005', 'Amelia Robinson', 17, 'M', 'AmeliaRobinson@rhyta.com', 7018525553, '1665 Findley Avenue Minot, ND 58701', 'Active');

UPDATE User_Position
SET Username = 'Whiscoget67'
WHERE User_Position.Position_ID = 'Lbr_00001';

UPDATE User_Position
SET Username = 'Bobre1950'
WHERE User_Position.Position_ID = 'Lec_00001';

UPDATE User_Position
SET Username = 'Wourell'
WHERE User_Position.Position_ID = 'Lec_00002';

UPDATE User_Position
SET Username = 'Pragnot245'
WHERE User_Position.Position_ID = 'Lec_00003';

UPDATE User_Position
SET Username = 'Fuldebou'
WHERE User_Position.Position_ID = 'Nms_00001';

UPDATE User_Position
SET Username = 'Ineved123'
WHERE User_Position.Position_ID = 'Std_00001';

UPDATE User_Position
SET Username = 'Undis1954'
WHERE User_Position.Position_ID = 'Std_00002';

UPDATE User_Position
SET Username = 'Saides'
WHERE User_Position.Position_ID = 'Std_00003';

UPDATE User_Position
SET Username = 'Anall1937'
WHERE User_Position.Position_ID = 'Std_00004';

UPDATE User_Position
SET Username = 'Nerisfamands'
WHERE User_Position.Position_ID = 'Std_00005';

UPDATE User_Position
SET Username = 'Haihey111'
WHERE User_Position.Position_ID = 'Std_00006';

INSERT INTO Login VALUES
('Undis1954', 'oSONkIE'),
('Haihey111', 'HUhkasfds'),
('Anall1937', 'm#68C7Cv'),
('Wourell', 'xA4$69F2'),
('Pragnot245', 'iCL82F7^'),
('Nerisfamands', 'lQ349&Lp'),
('Bobre1950', 'ws*N31C0'),
('Ineved123', 'aRDoROc'),
('Fuldebou', 'LK9&w24R'),
('Whiscoget67', 'q7Cx46C!'),
('Saides', 'TufuMpa');

INSERT INTO Publisher VALUES
('Pbs_00001', 'Prentice Hall', 'Rosie@gmail.com', '60 Lamphey Road THEDDLETHORPE ST HELENLN12 7TJ', 7981846167),
('Pbs_00002', 'Simon & Schuster Ltd (GB)', 'S&S@gmail.com', 'Plaza Pekeliling, No. 2, Jalan Tun Razak, Kuala Lumpur, 50400', 7763996293),
('Pbs_00003', 'Rosie Ltd', 'Rosie@gmail.com', 'Tingkat 13, Menara Johor Corporation, Kotaraya', 7984956167),
('Pbs_00004', 'Atria Ltd', 'Atria@gmail.com', '41 Huntly Street BARTHOL CHAPELAB51 5LS', 7979614114),
('Pbs_00005', 'Charles Publisher', 'Charles@gmail.com', 'Lot 635 & 660, Kawasan Perindustrian Tuanku Jaafar, Sungai Gadut, Seremban, 71450', 7016495987),
('Pbs_00006', 'John Brooks Ltd', 'John@gmail.com', '91 Dunmow Road GRIDLEY CORNER PL15 7LD', 7766694469),
('Pbs_00007', 'Connor & Nicholls', 'ConnorNicholls@gmail.com', '34 Nottingham RdABERFORD LS25 2BP', 7747780878),
('Pbs_00008', 'Penguin Publish', 'Penguin@gmail.comm', 'LINK Reservations Service Menara Dion 28-03,Kuala Lumpur, Wilayah Persekutuan, 50250', 7964478802);

INSERT INTO Author VALUES
('Ath_00001', 'Thomas Connolly', 44, 'Thomas@gmail.com'),
('Ath_00002', 'Ramez Elmasri', 50, 'Ramez@gmail.com'),
('Ath_00003', 'C.J. Date', 33, 'Date@gmail.com'),
('Ath_00004', 'Thomas Edwards', 30, 'ThomasEdwards@gmail.com'),
('Ath_00005', 'Colin Lincoln', 34, 'Colin@gmail.com'),
('Ath_00006', 'Colleen Hoover', 45, 'ColleenH@gmail.com'),
('Ath_00007', 'Luke Parkinson', 56, 'LukeParkinson@gmail.com'),
('Ath_00008', 'Libby Burns', 58, 'LibbyBurns@dayrep.com');

INSERT INTO Catalogue VALUES
('Ctg_00001', 'Delve into this stunning gift edition boasting the complete collection of Alice''s Adventures in Wonderland and Other Tales and original, iconic illustrations by John Tenniel.', 'Fantasy'),
('Ctg_00002', 'In this �brave and heartbreaking novel that digs its claws into you and doesn�t let go, long after you�ve finished it�', 'Romance'),
('Ctg_00003', 'The end of the year is fast approaching, and you know what that means. It''s time to get all of your end-of-year reviews in line.', 'Romance'),
('Ctg_00004', 'A short story is a great way to start a conversation about philosophical issues and concepts.', 'Philosophy'),
('Ctg_00005', 'I regret my sin. But I''ll never regret my time with you.', 'Novel'),
('Ctg_00006', 'A guide on the most important technologies you need to make your house a bit greener.', 'Technology'),
('Ctg_00007', 'In this sequel to The Iliad, Homer brings the war to the Trojan horse and launches the greatest attack of all time.', 'Novel'),
('Ctg_00008', 'The history of Japan is a long, complex, and often also confusing story. This concise, detailed guide to the history of Japan will give you a good overview of the country''s development.', 'History'),
('Ctg_00009', 'Honor is a British drama series on PBS. It was created by Tom Hanks, who also serves as executive producer. The series focuses on a diverse family of Washington, D.C., lawyers, most of whom are relatively young.', 'History'),
('Ctg_00010', 'A look at the author''s life as a deep-sea fisherman and his experiences of the depths of the ocean where all things are possible.', 'Autobiogr.'),
('Ctg_00011', 'This guide will help you learn German at home.', 'Language'),
('Ctg_00012', 'This is the best gift for a Hello gum lover.', 'Novel'),
('Ctg_00013', 'Learn how to build and manage a database program. This book is designed for readers with little or no programming experience.', 'Computing'),
('Ctg_00014', 'Learn how to make use of databases in your projects with these simple tips. from beginner to expert', 'Computing'),
('Ctg_00015', 'Learn all about databases and the SQL language, which is used to manipulate them.', 'Computing'),
('Ctg_00016', 'Find out how to build a database. SQL is the standard for relational databases and the most popular language for managing data.', 'Computing'),
('Ctg_00017', 'Covers many different programming languages, including Java, Python, Ruby, JavaScript, PHP, C, C++, SQL, HTML5, CSS3, and more.', 'Computing'),
('Ctg_00018', 'For this third edition of �Distributed Systems,� the material has been thoroughly revised and extended, integrating principles and paradigms into nine chapters.', 'Computing'),
('Ctg_00019', 'Python Parallel Programming is intended for software developers who are well versed with Python and want to use parallel programming techniques to write powerful and efficient code. ', 'Computing'),
('Ctg_00020', 'A young street hustler attempts to escape the rigors and temptations of the ghetto in a quest for a better life.', 'Crime');

INSERT INTO Book VALUES
('Bk_00001', 'Ctg_00001', 'Ath_00001', 'Pbs_00001', 4186261621497, 'Cyborg Without Direction', 'Open', 'English', 2019),
('Bk_00002', 'Ctg_00002', 'Ath_00002', 'Pbs_00002', 1238022326918, 'Boy Of Utopia', 'Open', 'English', 2011),
('Bk_00003', 'Ctg_00003', 'Ath_00002', 'Pbs_00002', 7758097345659, 'It Ends with you', 'Open', 'English', 2015),
('Bk_00004', 'Ctg_00004', 'Ath_00003', 'Pbs_00004', 9780735211292, 'The Storyteller : Tales of Life and Music', 'Yellow', 'English', 2013),
('Bk_00005', 'Ctg_00005', 'Ath_00004', 'Pbs_00005', 3718225576711, 'Regretting You', 'Yellow', 'English', 2016),
('Bk_00006', 'Ctg_00006', 'Ath_00007', 'Pbs_00006', 6211373520080, 'Research on green technology', 'Green', 'English', 2018),
('Bk_00007', 'Ctg_00007', 'Ath_00003', 'Pbs_00007', 4293234682839, 'Guardians And Soldiers', 'Yellow', 'English', 2017),
('Bk_00008', 'Ctg_00008', 'Ath_00001', 'Pbs_00001', 2788097345951, 'History of Japan', 'Green', 'English', 2018),
('Bk_00009', 'Ctg_00009', 'Ath_00003', 'Pbs_00008', 2511202593031, 'Anger With Honor', 'Yellow', 'English', 2019),
('Bk_00010', 'Ctg_00010', 'Ath_00005', 'Pbs_00006', 8121256298215, 'Drinking At The Depths', 'Red', 'English', 2018),
('Bk_00011', 'Ctg_00011', 'Ath_00004', 'Pbs_00003', 8128224526971, 'Learn German', 'Red', 'Chinese', 2019),
('Bk_00012', 'Ctg_00012', 'Ath_00002', 'Pbs_00005', 1238022326920, 'Hello Gum', 'Open', 'English', 2018),
('Bk_00013', 'Ctg_00013', 'Ath_00007', 'Pbs_00001', 9780123746306, 'Databases Systems', 'Green', 'English', 2019),
('Bk_00014', 'Ctg_00014', 'Ath_00002', 'Pbs_00001', 9781260515046, 'Databases System Concepts', 'Yellow', 'English', 2021),
('Bk_00015', 'Ctg_00015', 'Ath_00002', 'Pbs_00001', 9783658245481, 'SQL & NoSQL Databases', 'Red', 'English', 2019),
('Bk_00016', 'Ctg_00016', 'Ath_00002', 'Pbs_00001', 9780123820204, 'Databases Systems Modeling', 'Yellow', 'English', 2020),
('Bk_00017', 'Ctg_00017', 'Ath_00001', 'Pbs_00006', 9780470519820, 'Coding theory', 'Open', 'English', 2019),
('Bk_00018', 'Ctg_00018', 'Ath_00001', 'Pbs_00005', 9780521876346, 'Distributed systems', 'Green', 'English', 2017),
('Bk_00019', 'Ctg_00019', 'Ath_00003', 'Pbs_00005', 9781789533736, 'Python Parallel Programming', 'Green', 'English', 2020),
('Bk_00020', 'Ctg_00020', 'Ath_00002', 'Pbs_00006', 9780453627829, 'City of Menace', 'Open', 'English', 2019),
('Bk_00021', 'Ctg_00001', 'Ath_00001', 'Pbs_00001', 4186261621498, 'Cyborg Without Direction', 'Open', 'English', 2019),
('Bk_00022', 'Ctg_00002', 'Ath_00002', 'Pbs_00002', 1238022326919, 'Boy Of Utopia', 'Open', 'English', 2011),
('Bk_00023', 'Ctg_00003', 'Ath_00002', 'Pbs_00002', 7758097345660, 'It Ends with you', 'Open', 'English', 2015),
('Bk_00024', 'Ctg_00004', 'Ath_00003', 'Pbs_00004', 9780735211293, 'The Storyteller : Tales of Life and Music', 'Yellow', 'English', 2013),
('Bk_00025', 'Ctg_00005', 'Ath_00004', 'Pbs_00005', 3718225576712, 'Regretting You', 'Yellow', 'English', 2016),
('Bk_00026', 'Ctg_00006', 'Ath_00007', 'Pbs_00006', 6211373520081, 'Research on green technology', 'Yellow', 'English', 2018),
('Bk_00027', 'Ctg_00007', 'Ath_00003', 'Pbs_00007', 4293234682840, 'Guardians And Soldiers', 'Yellow', 'English', 2017),
('Bk_00028', 'Ctg_00008', 'Ath_00001', 'Pbs_00001', 2788097345952, 'History of Japan', 'Green', 'English', 2018),
('Bk_00029', 'Ctg_00009', 'Ath_00003', 'Pbs_00008', 2511202593032, 'Anger With Honor', 'Yellow', 'English', 2019),
('Bk_00030', 'Ctg_00010', 'Ath_00005', 'Pbs_00006', 8121256298216, 'Drinking At The Depths', 'Red', 'English', 2018),
('Bk_00031', 'Ctg_00011', 'Ath_00004', 'Pbs_00003', 8128224526972, 'Learn German', 'Red', 'Chinese', 2019),
('Bk_00032', 'Ctg_00012', 'Ath_00002', 'Pbs_00005', 1238022326921, 'Hello Gum', 'Open', 'English', 2018),
('Bk_00033', 'Ctg_00013', 'Ath_00007', 'Pbs_00001', 9780123746307, 'Databases Systems', 'Green', 'English', 2019),
('Bk_00034', 'Ctg_00014', 'Ath_00002', 'Pbs_00001', 9781260515047, 'Databases System Concepts', 'Yellow', 'English', 2021),
('Bk_00035', 'Ctg_00015', 'Ath_00002', 'Pbs_00001', 9783658245482, 'SQL & NoSQL Databases', 'Red', 'English', 2019),
('Bk_00036', 'Ctg_00016', 'Ath_00002', 'Pbs_00001', 9780123820205, 'Databases Systems Modeling', 'Yellow', 'English', 2020),
('Bk_00037', 'Ctg_00017', 'Ath_00001', 'Pbs_00006', 9780470519821, 'Coding theory', 'Open', 'English', 2019),
('Bk_00038', 'Ctg_00018', 'Ath_00001', 'Pbs_00005', 9780521876347, 'Distributed systems', 'Green', 'English', 2017),
('Bk_00039', 'Ctg_00019', 'Ath_00003', 'Pbs_00005', 9781789533737, 'Python Parallel Programming', 'Green', 'English', 2020),
('Bk_00040', 'Ctg_00020', 'Ath_00002', 'Pbs_00006', 9780453627830, 'City of Menace', 'Open', 'English', 2019);

INSERT INTO Borrowing_Activities VALUES
('Brw_00001', 'Anall1937', 'Bk_00001', '2022-07-11', '2022-07-27', '2022-07-25'),
('Brw_00002', 'Whiscoget67', 'Bk_00002', '2022-01-07', '2022-01-20', '2022-01-21'),
('Brw_00003', 'Undis1954', 'Bk_00012', '2022-01-07', '2022-01-20', '2022-01-21'),
('Brw_00004', 'Saides', 'Bk_00003', '2022-07-01', '2022-07-06', '2022-07-15'),
('Brw_00005', 'Saides', 'Bk_00004', '2022-07-21', '2022-07-27', '2022-07-28'),
('Brw_00006', 'Whiscoget67', 'Bk_00005', '2022-01-07', '2022-01-13', '2022-01-14'),
('Brw_00007', 'Bobre1950', 'Bk_00006', '2022-07-07', '2022-08-21', '2022-08-06'),
('Brw_00008', 'Wourell', 'Bk_00007', '2022-02-07', '2022-02-08', '2022-02-14'),
('Brw_00009', 'Pragnot245', 'Bk_00008', '2022-02-07', '2022-02-17', '2022-02-14'),
('Brw_00010', 'Nerisfamands', 'Bk_00009', '2022-05-07', '2022-05-08', '2022-05-10'),
('Brw_00011', 'Whiscoget67', 'Bk_00033', '2022-07-20', '2022-07-24', '2022-07-23'),
('Brw_00012', 'Fuldebou', 'Bk_00034', '2022-07-16', '2022-07-23', '2022-07-19'),
('Brw_00013', 'Undis1954', 'Bk_00013', '2022-01-07', '2022-01-23', '2022-01-21'),
('Brw_00014', 'Undis1954', 'Bk_00014', '2022-07-01', '2022-07-18', '2022-07-15'),
('Brw_00015', 'Undis1954', 'Bk_00038', '2022-07-21', '2022-08-01', '2022-07-28'),
('Brw_00016', 'Undis1954', 'Bk_00016', '2022-01-07', '2022-01-13', '2022-01-14'),
('Brw_00017', 'Saides', 'Bk_00017', '2022-07-07', '2022-08-08', '2022-08-06'),
('Brw_00018', 'Saides', 'Bk_00018', '2022-02-07', '2022-02-08', '2022-02-14'),
('Brw_00019', 'Saides', 'Bk_00019', '2022-02-07', '2022-02-17', '2022-02-14'),
('Brw_00020', 'Anall1937', 'Bk_00020', '2022-05-07', '2022-05-08', '2022-05-10'),
('Brw_00021', 'Anall1937', 'Bk_00021', '2022-07-20', '2022-07-24', '2022-07-23'),
('Brw_00022', 'Whiscoget67', 'Bk_00032', '2022-07-02', '2022-07-18', '2022-07-16'),
('Brw_00023', 'Nerisfamands', 'Bk_00040', '2022-07-22', '2022-08-08', '2022-08-05'),
('Brw_00024', 'Whiscoget67', 'Bk_00022', '2022-01-08', '2022-01-24', '2022-01-22'),
('Brw_00025', 'Nerisfamands', 'Bk_00023', '2022-07-08', '2022-07-27', '2022-07-22'),
('Brw_00026', 'Pragnot245', 'Bk_00024', '2022-02-08', '2022-02-17', '2022-02-15'),
('Brw_00027', 'Wourell', 'Bk_00025', '2022-02-08', '2022-02-18', '2022-02-15'),
('Brw_00028', 'Wourell', 'Bk_00026', '2022-05-08', '2022-05-27', '2022-05-15'),
('Brw_00029', 'Whiscoget67', 'Bk_00027', '2022-07-21', '2022-07-31', '2022-07-28'),
('Brw_00030', 'Nerisfamands', 'Bk_00027', '2022-08-07', '2022-08-20', '2022-08-14');

INSERT INTO Fine VALUES
('Fine_00001', 'Anall1937', 'Brw_00001', 2, 40),
('Fine_00002', 'Bobre1950', 'Brw_00007', 15, 125),
('Fine_00003', 'Pragnot245', 'Brw_00009', 3, 65),
('Fine_00004', 'Whiscoget67', 'Brw_00011', 1, 55),
('Fine_00005', 'Fuldebou', 'Brw_00012', 4, 60),
('Fine_00006', 'Saides', 'Brw_00017', 2, 40),
('Fine_00007', 'Saides', 'Brw_00019', 3, 65),
('Fine_00008', 'Anall1937', 'Brw_00021', 1, 35),
('Fine_00009', 'Whiscoget67', 'Brw_00022', 2, 40),
('Fine_00010', 'Nerisfamands', 'Brw_00023', 3, 45),
('Fine_00011', 'Whiscoget67', 'Brw_00024', 2, 40),
('Fine_00012', 'Nerisfamands', 'Brw_00025', 5, 55),
('Fine_00013', 'Pragnot245', 'Brw_00026', 2, 50),
('Fine_00014', 'Wourell', 'Brw_00027', 3, 55),
('Fine_00015', 'Wourell', 'Brw_00028', 12, 100),
('Fine_00016', 'Whiscoget67', 'Brw_00029', 3, 55),
('Fine_00017', 'Nerisfamands', 'Brw_00030', 6, 70),
('Fine_00018', 'Undis1954', 'Brw_00013', 2, 60),
('Fine_00019', 'Undis1954', 'Brw_00014', 3, 55),
('Fine_00020', 'Undis1954', 'Brw_00015', 4, 70);

INSERT INTO Reservations VALUES
('Re_0001', 'Bk_00020', 'Saides', '2022-04-07', 'loaned out'),
('Re_0002', 'Bk_00040', 'Bobre1950', '2022-07-23', 'available'),
('Re_0003', 'Bk_00011', 'Wourell', '2022-07-15', 'available'),
('Re_0004', 'Bk_00012', 'Nerisfamands', '2022-08-07', 'available'),
('Re_0005', 'Bk_00013', 'Whiscoget67', '2022-07-25', 'available'),
('Re_0006', 'Bk_00018', 'Anall1937', '2022-07-15', 'available'),
('Re_0007', 'Bk_00009', 'Wourell', '2022-05-09', 'available'),
('Re_0008', 'Bk_00002', 'Pragnot245', '2022-02-10', 'available'),
('Re_0009', 'Bk_00010', 'Nerisfamands', '2022-07-22', 'loaned out'),
('Re_0010', 'Bk_00003', 'Bobre1950', '2022-06-07', 'loaned out');